const api_Key = "QjT4CQjigDKEKQuc0p5bzcjzHqAOQeRU";

export {getPopularEvents, searchEventById, searchEventsByName, searchEventsByNameNoId}
async function getPopularEvents(req, res) {


    const s = req.query.s || 30; //30 é o valor default 
    const p = req.query.p || 1; //1 é o valor default

    const apiUrl = `https://app.ticketmaster.com/discovery/v2/events/?sort=relevance,desc&size=${s}&pages=${p}&apikey=${api_Key}`;

    try{
        const resposta = await fetch(apiUrl);
        const respostaFormatada = format(await resposta.json());
        return res.status(200).json({data: respostaFormatada});

    }catch(erro){
        console.log('Erro a ir buscar os eventos mais populares');
        return res.status(500).json(erro);

    }
}

async function searchEventsByName(req, res) {

    const nome = req.body.eventName; //nome específico do evento
    const idGrupo = req.body.idGrupo; //idGrupo da rota
    const s = req.body.s || 30; // 30 default 
    const p = req.body.p || 1; // valor default
    const apiUrl = `https://app.ticketmaster.com/discovery/v2/events/?sort=relevance,desc&size=${s}&pages=${p}&keyword=${nome}&apikey=${api_Key}`;
  
    try {
        
        const resposta = await fetch(apiUrl);
        if(!resposta.ok){
            console.log("erro")
        }
        else{
            const resposta1= await resposta.json();
            if(resposta1._embedded && resposta1._embedded.events.length > 0){
                return res.render('searchevents', {
                    idGrupo: idGrupo,
                    events: format(resposta1)
                });
            }
            else{
                return res.render('searchevents', {
                    idGrupo: idGrupo,
                    events: {}
                });
            }
        }
        
        
    } catch (erro) {
        console.log('Erro a ir buscar os eventos mais populares');
        return res.render('searchevents', {
            idGrupo: idGrupo,
            events: {}
        });
    }
}


async function searchEventsByNameNoId(req, res) {

    const nome = req.query.Event; //nome específico do evento
    const s = req.query.s || 30; // 30 default 
    const p = req.query.p || 1; // valor default
    const apiUrl = `https://app.ticketmaster.com/discovery/v2/events/?sort=relevance,desc&size=${s}&pages=${p}&keyword=${nome}&apikey=${api_Key}`;
  
    try {
        const resposta = await fetch(apiUrl);
        if(!resposta.ok){
            res.render('searcheventsnogroup', {
                events: {}
            });
        }
        else{
            const respostaFormatada = format(await resposta.json());
            res.render('searcheventsnogroup', {
                events: respostaFormatada
            });
        }

    } catch (erro) {
        console.log('Erro a ir buscar os eventos mais populares');
        res.render('searcheventsnogroup', {
            events: {}
        });
    }
}

/*
igual ao getPopularEvents mas o url inclui o nome do evento pretendido
*/

async function searchEventById(eventId){

    //ir buscar o nome especifico do evento
    const apiUrl = `https://app.ticketmaster.com/discovery/v2/events/${eventId}.json?apikey=${api_Key}`;
  
    try{
        const resposta = await fetch(apiUrl);
        // console.log("resposta heyy");
        const respostaJSON = await resposta.json()
        const respostaFormatada = formatEvent(respostaJSON);
        return respostaFormatada
        
    }catch(erro){
        console.log('Erro a ir buscar os eventos mais populares');
        // return res.status(500).json({erro: 'erro no servidor'});
    };

}


function format(res){

    return res._embedded.events.map( res => {
        return {
            id: res.id, 
            name: res.name,
            image: res.images && res.images.length > 0 ? res.images[0].url : null,
            sales: res.sales && res.sales.public && res.sales.public.startDateTime && res.sales.public.endDateTime
                ? `${res.sales.public.startDateTime} - ${res.sales.public.endDateTime}`
                : 'N/A',
            date: res.dates.start.dateTime,
            segment: res.classifications && res.classifications.length > 0
                ? res.classifications[0].segment.name
                : 'N/A',
            genre: res.classifications && res.classifications.length > 0
                ? res.classifications[0].genre.name
                : 'N/A',
            subGenre: res.classifications && res.classifications.length > 0 && res.classifications[0].subGenre
                ? res.classifications[0].subGenre.name
                : 'N/A',
        }
    });

}

function formatEvent(res){

    return {
        id: res.id, 
        name: res.name,
        image: res.images && res.images.length > 0 ? res.images[0].url : null,
        sales: res.sales && res.sales.public && res.sales.public.startDateTime && res.sales.public.endDateTime
            ? `${res.sales.public.startDateTime} - ${res.sales.public.endDateTime}`
            : 'N/A',
        date: res.dates.start.dateTime,
        segment: res.classifications && res.classifications.length > 0
            ? res.classifications[0].segment.name
            : 'N/A',
        genre: res.classifications && res.classifications.length > 0
            ? res.classifications[0].genre.name
            : 'N/A',
        subGenre: res.classifications && res.classifications.length > 0 && res.classifications[0].subGenre
            ? res.classifications[0].subGenre.name
            : 'N/A',
    }

}

