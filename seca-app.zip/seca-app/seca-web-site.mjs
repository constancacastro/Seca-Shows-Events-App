
import secaServices from './seca-services.mjs';
import {engine} from 'express-handlebars';
//import { getPopularEvents, searchEventsByName } from './tm-events-data.mjs';
import secaDataElastic from './data/elastic/seca-data-elastic.mjs';
import { getPopularEvents, searchEventsByName, searchEventById } from './tm-events-data.mjs';
import express from 'express';
import { grupo, user, event } from './seca-data-mem.mjs';
import crypto from 'crypto'
{grupo, user, event}


export const secaWebSite = {

    async login(req, res) {
        try {
            const username = req.body.Username;
            const password = req.body.Password;

            const alreadyUser = await secaServices().logIn(username, password);
            // console.log(alreadyUser);

            if (alreadyUser.idToken == null) {
                res.redirect('/home');
            } else {
                //res.render('userpage', { idToken: alreadyUser.idToken }); P3
                req.login(alreadyUser.idToken, () => res.redirect('/home/userpage'));
                //console.log('chega a dar o redirect?')
                //console.log('sim');
            }

        } catch (err) {
            console.error(err); 
            res.status(500).send('Erro no server'); 
        }
    },

    async register(req, res){
        try{
            const username = req.body.Username
            const password = req.body.Password

                //console.log(username, password) 

            const newUser = await secaServices().Register(username, password)
            
                //console.log(newUser) 

            if (newUser != null){ 
            //newUser != null quando é um novo user
                //console.log('funcionouuuuu')
                //res.render('userpage', {idToken: newUser.idToken} ); P3
                req.login(newUser.idToken, () => res.redirect('/home/groups/valid'));
            } else {
            //newUser = null quando existe
                res.render('home');
            }
 
         }catch(err){
            console.error(err); 
            res.status(500).send('Erro no server'); 
         };
    },

    async getGroups(req, res){
        try{
                //console.log("entrou");
            //const idToken = req.params.idToken; P3
            const idToken = req.user;
                //console.log(idToken);
                // console.log("chega aqui");
            const userGroups = await secaDataElastic('groups').getGroups(idToken);
            console.log(userGroups);
            res.render('groups',{ userGroups: userGroups, idToken: idToken});
        }catch(err){
            console.error(err); 
        }
    },

    async renderEditPage(req, res){

        const grupo = await secaDataElastic('groups').getGroup(req.body.idGrupo);

        res.render('editPage', {
            title: 'Edit your Group',
            grupo: grupo,
            style: 'editPage.css'
        });
    },

    
    async getDetails(req, res){
        try{
            const idGrupo = req.body.idGrupo;
            const grupo = await secaDataElastic("groups").getGroup(idGrupo);
            res.render('groupdetails', {grupo: grupo});
            
        }catch(err){
            console.log('erro ', err);
        }

    },
    async updateGroup(req, res){
        try{
            const idGrupo = req.body.idGrupo;
            const nameGrupo = req.body.newGroupName;
            const descGrupo = req.body.newGroupDescription;

            const currGrupo = await secaDataElastic('groups').getGroup(idGrupo); //grupo guardado na data base c nome e desc antigos
            
            currGrupo.nome = nameGrupo;
            currGrupo.descricao = descGrupo;

            await secaDataElastic('groups').updateGroup(currGrupo);
            //const updatedGroups = await secaDataElastic('groups').getGroups(currGrupo.idToken);

            res.redirect(`/home/groups/valid`);

        }catch(err){
            console.log('erro ', err)
        }
    },

    async deleteGroup(req, res){
        try{
            

            const idGrupo = req.body.idGrupo;
            const grupo = await secaDataElastic('groups').getGroup(idGrupo);

            await secaDataElastic('groups').deleteGroup(idGrupo);

            res.redirect(`/home/groups/valid`);

        }catch(err){
            console.log('erro ', err)
        }
    },
    async deleteEvent(req, res){
        try{

            const idGrupo = req.body.idGrupo;
            const idEvento = req.body.eventId;
            const grupo = await secaDataElastic('groups').getGroup(idGrupo);

            const indexEvento = grupo.eventos.findIndex(evento => evento.id == idEvento);
            grupo.eventos.splice(indexEvento, 1);

            await secaDataElastic("groups").updateGroup(grupo);
            res.redirect(`/home/groups/valid`);

        }catch(err){
            console.log('erro ', err)
        }
    },
/*
    async createGroup(req, res){
        try{

            const { GroupName, GroupDescription } = req.body;
            let idToken = req.params.idToken;
    
            const newGroup = {
                nome: GroupName,
                descricao: GroupDescription,
                idGrupo: crypto.randomUUID(),
                eventos: []
            };
    
            console.log('Creating new group:', newGroup);
    
            const groupCreated = await secaDataElastic(groups).insertGroup(newGroup);
            console.log('Group created:', groupCreated);
    
            // const updatedGroups = await secaDataElastic(groups).getGroups(idToken);
            // console.log('Updated groups:', updatedGroups);
    
            res.redirect(`/home/groups/${idToken}`, { userGroups: groupCreated });


        }catch(err){
            console.log('erro ', err)
        }
    },
    */

    async createGroup(req, res) {
        try {
            const GroupName = req.body.GroupName;
            const GroupDescription = req.body.GroupDescription;
            
            const idToken = req.user;
            // console.log(GroupName, GroupDescription, idToken)

            const newGroup = {
                nome: GroupName,
                descricao: GroupDescription,
                // idGrupo: crypto.randomUUID(),
                idToken: idToken,
                eventos: []
            };
    
            // console.log('Creating new group:', newGroup);
    
            const groupCreated = await secaDataElastic('groups').insertGroup(newGroup);
            console.log('Group created:', groupCreated);
    
           //res.redirect(`/home/groups/${idToken}`); P3
           res.redirect(`/home/groups/valid`);
        } catch (err) {
            console.log('erro ', err);
        }
    },


    async loadAddEvent(req, res){
        try{
            const idGrupo = req.body.idGrupo;
            res.render('searchevents', {idGrupo: idGrupo})
        }catch(err){
            console.log('erro ', err)
        }
    },

    async addEventToGroup(req, res){
        try{

            const event = await searchEventById(req.body.eventid);
            const group = await secaDataElastic('groups').getGroup(req.body.idGrupo);

            // console.log("blbla")
            console.log(event)
            console.log(group)

            let flag = false
            for(const event1 of group.eventos){
                if(event1.id === event.id){
                    flag = true
                }
            }
            if(!flag){
                group.eventos.push(event);
                await secaDataElastic('groups').updateGroup(group);
            }
            
            res.render('groupdetails',{grupo: group});

        }catch(err){
            console.log('erro ', err)
        }
    },

    async isValidUser(req, res){
        try{


            const username = req.params.username
            const password = req.params.password


            if (username == null) {
                res.redirect('/home/userpage')
            }
            else{
                res.redirect(`/home/register`);
            }
        }catch(err){
            console.log('Error validating user:', err);
            return false;
        }
    }
}
    
export default secaWebSite;