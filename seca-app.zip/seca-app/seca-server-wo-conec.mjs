import express from 'express'
import { blabla } from './seca-web-api.mjs';
import {engine} from 'express-handlebars';
import { secaWebSite } from './seca-web-site.mjs';
import secaServices from './seca-services.mjs';
import { getPopularEvents, searchEventsByName, searchEventById } from './tm-events-data.mjs';


const PORT = 4000 ;

const app = express();  //iniciar um objeto express
// blabla(app)
app.engine('handlebars', engine('main'));
app.set('view engine', 'handlebars');
app.use(express.urlencoded());

app.use(express.static('public/styles')); //fazer com que aceda à pasta onde está o css

//rotas site
app.get('/home', (req,res) => {
   res.render('home', { title: 'SECA',
   style: 'home.css'
   })
});

//rota login
app.get('/login', (req, res) => {
   res.render('login', { title: 'SECA' ,
   style: 'login.css'
   });
});

//rota registo
app.get('/register', (req, res) => {
   res.render('register', { title: 'SECA' ,
   style: 'register.css'
   });
});

app.get('/userpage', (req, res) => {
   res.render('userpage', { title: 'SECA' , 
   style: 'userpage.css'
   });
});

app.get('/groups', (req, res) => {
   res.render('groups', { title: 'SECA' ,
   style: 'groups.css'
  });
});

app.get('/searchevents', (req, res) => {
   res.render('searchevents', { title: 'Search for Events' ,
   style: 'searchevents.css'
   });
});

//rotas pra paginas
app.get('/home/loginpage', (req, res) => {
   res.render('login', {action: '/home/login',
    buttonValue: 'Login'});
});
app.get('/home/signuppage', (req, res) => {
   res.render('register', 
   {action: '/home/signup',
    buttonValue: 'Sign up'});
});

//rotas para elastic
// app.post('/home/login', secaWebSite.login);
// app.post('/home/signup', secaWebSite.register);
// app.get('/home/groups', secaWebSite.getGroups);
// app.get('/home/groups/details', secaWebSite.getDetails);
// app.post('/rotadoupdate', secaWebSite.updateGroup);
// app.post('/rotadodeleteo', secaWebSite.deleteGroup);
// app.get('/rotadoadd', secaWebSite.loadAddEvent);
// app.get('/rotadosevents', searchEventsByName) //nao esquecer de meter idGrupo
// app.post('/addgroup', secaWebSite.addEventToGroup)

/*
app.post('/home/login', secaWebSite.login);
app.post('/home/signup', secaWebSite.register);
app.get('/home/groups/:idToken', secaWebSite.getGroups);
app.get('/home/groups/:idGrupo/details', secaWebSite.getDetails);
app.post('/rotadoupdate/:idGrupo', secaWebSite.updateGroup);
app.post('/rotadodelete/:idGrupo', secaWebSite.deleteGroup);
app.get('/rotadoadd/:idGrupo', secaWebSite.loadAddEvent);
app.get('/rotadosevents/:idGrupo', searchEventsByName) //nao esquecer de meter idGrupo
app.post('/addgroup/:idGrupo', secaWebSite.addEventToGroup)

*/

app.listen(PORT, () => {
   console.log(`Servidor está a correr na porta ${PORT}`); 
}); //inicializar o servidor

//mudei so os ficheiros que tao fora das pastas, dentro do views