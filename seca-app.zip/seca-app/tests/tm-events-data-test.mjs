const { expect } = require('chai');
const { getPopularEvents, searchEventsByName} = require('./tm-events-data'); // Replace with the correct path
const fetch = require('node-fetch');

class MockResponse {
  constructor() {
    this.statusCode = 200;
    this.data = null;
  }

  code(statusCode) {
    this.statusCode = statusCode;
    return this;
  }

  json(data) {
    this.data = data;
    return this;
  }
}

describe('getPopularEvents', () => {
  it('should return popular events for valid parameters', async () => {
    const req = { query: { s: 30, p: 1 } };
    const res = new MockResponse();
    const api_Key = 'QjT4CQjigDKEKQuc0p5bzcjzHqAOQeRU';
    const fetchStub = () => Promise.resolve({ json: async () => ({ events: ['event1', 'event2'] }) });
    
    const originalFetch = global.fetch;
    global.fetch = fetchStub;

    await getPopularEvents(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ data: ['event1', 'event2'] });
    global.fetch = originalFetch;
  });

  it('should handle default parameters correctly', async () => {
    const req = { query: {} }; d
    const res = new MockResponse();
    const api_Key = 'QjT4CQjigDKEKQuc0p5bzcjzHqAOQeRU'; 
    const fetchStub = () => Promise.resolve({ json: async () => ({ events: ['defaultEvent1', 'defaultEvent2'] }) });
    
    const originalFetch = global.fetch;
    global.fetch = fetchStub;

    await getPopularEvents(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ data: ['defaultEvent1', 'defaultEvent2'] });

    global.fetch = originalFetch;
  });

  it('should handle errors from the external API', async () => {
    const req = { query: { s: 30, p: 1 } };
    const res = new MockResponse();
    const api_Key = 'QjT4CQjigDKEKQuc0p5bzcjzHqAOQeRU'; 
    const fetchStub = () => Promise.reject('Error from external API');
    

    const originalFetch = global.fetch;
    global.fetch = fetchStub;

    await getPopularEvents(req, res);

    expect(res.statusCode).to.equal(500);
    expect(res.data).to.equal('Error from external API');

    global.fetch = originalFetch;
  });
});

describe('searchEventsByName', () => {
  it('should return events by name for valid parameters', async () => {
    const req = { query: { eventName: 'EventName', s: 30, p: 1 } };
    const res = new MockResponse();
    const api_Key = 'QjT4CQjigDKEKQuc0p5bzcjzHqAOQeRU'; 
    const fetchStub = () => Promise.resolve({ json: async () => ({ events: ['event1', 'event2'] }) });

    const originalFetch = global.fetch;
    global.fetch = fetchStub;

    await searchEventsByName(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ data: ['event1', 'event2'] });


    global.fetch = originalFetch;
  });

  it('should handle default parameters correctly', async () => {
    const req = { query: { eventName: 'EventName' } }; 
    const res = new MockResponse();
    const api_Key = 'QjT4CQjigDKEKQuc0p5bzcjzHqAOQeRU'; 
    const fetchStub = () => Promise.resolve({ json: async () => ({ events: ['defaultEvent1', 'defaultEvent2'] }) });

  
    const originalFetch = global.fetch;
    global.fetch = fetchStub;

    await searchEventsByName(req, res);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ data: ['defaultEvent1', 'defaultEvent2'] });

    global.fetch = originalFetch;
  });

  it('should handle errors from the external API', async () => {
    const req = { query: { eventName: 'EventName', s: 30, p: 1 } };
    const res = new MockResponse();
    const api_Key = 'QjT4CQjigDKEKQuc0p5bzcjzHqAOQeRU'; 
    const fetchStub = () => Promise.reject('Error from external API');

  
    const originalFetch = global.fetch;
    global.fetch = fetchStub;

    await searchEventsByName(req, res);

    expect(res.statusCode).to.equal(500);
    expect(res.data).to.deep.equal({ erro: 'erro no servidor' });

    global.fetch = originalFetch;
  });
});


describe('format', () => {
  it('should format events correctly', () => {
    const response = {
      _embedded: {
        events: [
          { name: 'Event1', dates: { start: { dateTime: '2023-01-01T18:00:00' } } },
          { name: 'Event2', dates: { start: { dateTime: '2023-02-01T19:30:00' } } },
        ],
      },
    };

    const formattedEvents = format(response);

    expect(formattedEvents).to.be.an('array');
    expect(formattedEvents).to.have.lengthOf(2);

    expect(formattedEvents[0]).to.deep.equal({ name: 'Event1', date: '2023-01-01T18:00:00' });
    expect(formattedEvents[1]).to.deep.equal({ name: 'Event2', date: '2023-02-01T19:30:00' });
  });

  it('should handle empty response', () => {
    const response = { _embedded: { events: [] } };

    const formattedEvents = format(response);

    expect(formattedEvents).to.be.an('array').that.is.empty;
  });

  it('should handle missing or invalid data', () => {
    const response = {
      _embedded: {
        events: [
          { name: 'Event1', dates: { start: { dateTime: '2023-01-01T18:00:00' } } },
          { name: 'Event2' },
        ],
      },
    };

    const formattedEvents = format(response);

    expect(formattedEvents).to.be.an('array').that.has.lengthOf(1);
    expect(formattedEvents[0]).to.deep.equal({ name: 'Event1', date: '2023-01-01T18:00:00' });
  });
});

