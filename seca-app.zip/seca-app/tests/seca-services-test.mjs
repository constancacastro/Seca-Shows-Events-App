const { expect } = require('chai');
const { getAllGroups, allGroups, getGroup, insertGroup, updateGroup, deleteGroup, insertUser, deleteEvent } = require('./seca-services'); // Replace with the correct path

class MockResponse {
  constructor() {
    this.statusCode = 200;
    this.data = null;
  }

  code(statusCode) {
    this.statusCode = statusCode;
    return this;
  }

  json(data) {
    this.data = data;
    return this;
  }
}

describe('getAllGroups', () => {
  it('should return groups when the userToken exists', async () => {
    const req = { query: { userToken: 'validToken' } };
    const res = {
      status: (code) => ({ json: (data) => ({ code, data }) }),
    };

    const result = await getAllGroups(req, res);

    expect(result.code).to.equal(200);
    expect(result.data.msg).to.equal('Token existe e vai buscar os grupos');
    expect(result.data.grupos).to.be.an('array'); // Assuming groups is an array
  });

  it('should return an error when the userToken does not exist', async () => {
    const req = { query: { userToken: 'nonExistentToken' } };
    const res = {
      status: (code) => ({ json: (data) => ({ code, data }) }),
    };

    const result = await getAllGroups(req, res);

    expect(result.code).to.equal(403);
    expect(result.data.erro).to.equal('Não existe este token');
  });

  it('should handle errors gracefully', async () => {
    const req = { query: { userToken: 'validToken' } };
    const res = {
      status: (code) => ({ json: (data) => ({ code, data }) }),
    };
    const result = await getAllGroups({ ...req, throwOnError: true }, res);

    expect(result.code).to.equal(500);
    expect(result.data).to.be.undefined;
  });
});


describe('allGroups', () => {
  it('should return an array of groups for a valid userToken', () => {
    const userToken = 'validToken';
    const grupos = new Map([
      [1, { idUser: 'validToken', name: 'Group 1' }],
      [2, { idUser: 'validToken', name: 'Group 2' }],
      [3, { idUser: 'otherToken', name: 'Group 3' }],
    ]);

    const result = allGroups(userToken, grupos);

    expect(result).to.be.an('array');
    expect(result).to.have.lengthOf(2);
    expect(result[0].name).to.equal('Group 1');
    expect(result[1].name).to.equal('Group 2');
  });

  it('should return an empty array for an invalid userToken', () => {
    const userToken = 'invalidToken';
    const grupos = new Map([
      [1, { idUser: 'validToken', name: 'Group 1' }],
      [2, { idUser: 'validToken', name: 'Group 2' }],
      [3, { idUser: 'otherToken', name: 'Group 3' }],
    ]);

    const result = allGroups(userToken, grupos);

    expect(result).to.be.an('array').that.is.empty;
  });
});


describe('getGroup', () => {
  it('should return the group for a valid userToken and idGrupo', async () => {
    const req = { query: { userToken: 'validToken', idGrupo: 'groupId' } };
    const res = {
      code: (statusCode) => ({ json: (data) => ({ statusCode, data }) }),
    };
    const users = new Map([
      ['validToken', 'UserName'],
      ['otherToken', 'OtherUserName'],
    ]);
    const grupos = new Map([
      ['groupId', { idGrupo: 'groupId', userToken: 'validToken', idToken: 'validToken', name: 'Group 1' }],
      ['otherGroupId', { idGrupo: 'otherGroupId', userToken: 'otherToken', idToken: 'otherToken', name: 'Group 2' }],
    ]);

    const result = await getGroup(req, res, users, grupos);

    expect(result.statusCode).to.equal(200);
    expect(result.data).to.deep.equal({ data: { idGrupo: 'groupId', userToken: 'validToken', idToken: 'validToken', name: 'Group 1' } });
  });

  it('should return an error for an invalid userToken', async () => {
    const req = { query: { userToken: 'invalidToken', idGrupo: 'groupId' } };
    const res = {
      code: (statusCode) => ({ json: (data) => ({ statusCode, data }) }),
    };
    const users = new Map([
      ['validToken', 'UserName'],
      ['otherToken', 'OtherUserName'],
    ]);
    const grupos = new Map([
      ['groupId', { idGrupo: 'groupId', userToken: 'validToken', idToken: 'validToken', name: 'Group 1' }],
      ['otherGroupId', { idGrupo: 'otherGroupId', userToken: 'otherToken', idToken: 'otherToken', name: 'Group 2' }],
    ]);

    const result = await getGroup(req, res, users, grupos);

    expect(result.statusCode).to.equal(403);
    expect(result.data).to.deep.equal({ erro: 'token não válido' });
  });

  it('should return an error for an invalid idGrupo', async () => {
    const req = { query: { userToken: 'validToken', idGrupo: 'invalidGroupId' } };
    const res = {
      code: (statusCode) => ({ json: (data) => ({ statusCode, data }) }),
    };
    const users = new Map([
      ['validToken', 'UserName'],
      ['otherToken', 'OtherUserName'],
    ]);
    const grupos = new Map([
      ['groupId', { idGrupo: 'groupId', userToken: 'validToken', idToken: 'validToken', name: 'Group 1' }],
      ['otherGroupId', { idGrupo: 'otherGroupId', userToken: 'otherToken', idToken: 'otherToken', name: 'Group 2' }],
    ]);

    const result = await getGroup(req, res, users, grupos);

    expect(result.statusCode).to.equal(403);
    expect(result.data).to.deep.equal({ erro: 'token não válido' });
  });

  it('should return an error for a server error', async () => {
    const req = { query: { userToken: 'validToken', idGrupo: 'groupId' } };
    const res = {
      code: (statusCode) => ({ json: (data) => ({ statusCode, data }) }),
    };
    const users = new Map([
      ['validToken', 'UserName'],
      ['otherToken', 'OtherUserName'],
    ]);
    const grupos = new Map([
      ['groupId', { idGrupo: 'groupId', userToken: 'validToken', idToken: 'validToken', name: 'Group 1' }],
      ['otherGroupId', { idGrupo: 'otherGroupId', userToken: 'otherToken', idToken: 'otherToken', name: 'Group 2' }],
    ]);

    const result = await getGroup({ ...req, throwServerError: true }, res, users, grupos);

    expect(result.statusCode).to.equal(500);
    expect(result.data).to.deep.equal({ erro: 'erro no servidor' });
  });
});


describe('insertGroup', () => {
  it('should insert a group and return success message for valid parameters and token', async () => {
    const req = { query: { name: 'Group 1', descricao: 'Description', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map();

    await insertGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ success: true, message: 'Grupo inserido com sucesso' });
    expect(allGroups.size).to.equal(1); // Assumindo que o grupo foi adicionado ao (map)
  });

  it('should return an error for an invalid token', async () => {
    const req = { query: { name: 'Group 1', descricao: 'Description', idToken: 'invalidToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map();

    await insertGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(403);
    expect(res.data).to.deep.equal({ erro: 'token não válido' });
    expect(allGroups.size).to.equal(0); // Nenhum grupo foi adicionado
  });

  it('should return an error for missing parameters', async () => {
    const req = { query: { idToken: 'validToken' } }; // Não tem nome e descrição
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map();

    await insertGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(400);
    expect(res.data).to.deep.equal({ erro: 'parâmetros mal passados' });
    expect(allGroups.size).to.equal(0); // Nenhum grupo foi adicionado ao map
  });

  it('should return an error for a server error', async () => {
    const req = { query: { name: 'Group 1', descricao: 'Description', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map();

    await insertGroup({ ...req, throwServerError: true }, res, users, allGroups);

    expect(res.statusCode).to.equal(500);
    expect(res.data).to.deep.equal({ erro: 'erro no servidor' });
    expect(allGroups.size).to.equal(0); // Nenhum grupo foi adicionado ao map
  });
});


describe('updateGroup', () => {
  it('should update the group name for valid parameters and token', async () => {
    const req = { query: { idGroup: 'groupId', newName: 'NewName', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGroup: 'groupId', name: 'OldName', descricao: 'OldDescription', idToken: 'validToken' }]]);

    await updateGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ success: true, message: 'Grupo atualizado com sucesso' });
    expect(allGroups.get('groupId').name).to.equal('NewName');
  });

  it('should update the group description for valid parameters and token', async () => {
    const req = { query: { idGroup: 'groupId', newDescricao: 'NewDescription', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGroup: 'groupId', name: 'OldName', descricao: 'OldDescription', idToken: 'validToken' }]]);

    await updateGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ success: true, message: 'Grupo atualizado com sucesso' });
    expect(allGroups.get('groupId').descricao).to.equal('NewDescription');
  });

  it('should return an error for an invalid token', async () => {
    const req = { query: { idGroup: 'groupId', newName: 'NewName', idToken: 'invalidToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGroup: 'groupId', name: 'OldName', descricao: 'OldDescription', idToken: 'validToken' }]]);

    await updateGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(403);
    expect(res.data).to.deep.equal({ erro: 'token não válido' });
    expect(allGroups.get('groupId').name).to.equal('OldName');
  });

  it('should return an error for missing parameters', async () => {
    const req = { query: { idGroup: 'groupId', idToken: 'validToken' } }; 
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGroup: 'groupId', name: 'OldName', descricao: 'OldDescription', idToken: 'validToken' }]]);

    await updateGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(400);
    expect(res.data).to.deep.equal({ erro: 'parâmetros mal passados' });
    expect(allGroups.get('groupId').name).to.equal('OldName'); 
    expect(allGroups.get('groupId').descricao).to.equal('OldDescription'); 
  });

  it('should return an error for a non-existing group', async () => {
    const req = { query: { idGroup: 'nonExistingGroupId', newName: 'NewName', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map();

    await updateGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(404);
    expect(res.data).to.deep.equal({ erro: 'grupo não encontrado' });
  });

  it('should return an error for a server error', async () => {
    const req = { query: { idGroup: 'groupId', newName: 'NewName', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGroup: 'groupId', name: 'OldName', descricao: 'OldDescription', idToken: 'validToken' }]]);

    await updateGroup({ ...req, throwServerError: true }, res, users, allGroups);

    expect(res.statusCode).to.equal(500);
    expect(res.data).to.deep.equal({ erro: 'erro no servidor' });
  });
});


describe('deleteGroup', () => {
  it('should delete the group for valid parameters and token', async () => {
    const req = { query: { idGrupo: 'groupId', userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGrupo: 'groupId', name: 'Group1', descricao: 'Description', idToken: 'validToken' }]]);

    await deleteGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ msg: 'Grupo eliminado com sucesso' });
    expect(allGroups.has('groupId')).to.be.false; 
  });

  it('should return an error for an invalid token', async () => {
    const req = { query: { idGrupo: 'groupId', userToken: 'invalidToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGrupo: 'groupId', name: 'Group1', descricao: 'Description', idToken: 'validToken' }]]);

    await deleteGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(403);
    expect(res.data).to.deep.equal({ erro: 'Token inválido' });
    expect(allGroups.has('groupId')).to.be.true; 
  });

  it('should return an error for missing parameters', async () => {
    const req = { query: { userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGrupo: 'groupId', name: 'Group1', descricao: 'Description', idToken: 'validToken' }]]);

    await deleteGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(400);
    expect(res.data).to.deep.equal({ erro: 'Parâmetro mal passado' });
    expect(allGroups.has('groupId')).to.be.true; 
  });

  it('should return an error for a non-existing group', async () => {
    const req = { query: { idGrupo: 'nonExistingGroupId', userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map();

    await deleteGroup(req, res, users, allGroups);

    expect(res.statusCode).to.equal(404);
    expect(res.data).to.deep.equal({ erro: 'Grupo não encontrado' });
  });

  it('should return an error for a server error', async () => {
    const req = { query: { idGrupo: 'groupId', userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allGroups = new Map([['groupId', { idGrupo: 'groupId', name: 'Group1', descricao: 'Description', idToken: 'validToken' }]]);

   
    await deleteGroup({ ...req, throwServerError: true }, res, users, allGroups);

    expect(res.statusCode).to.equal(500);
    expect(res.data).to.deep.equal({ erro: 'Erro no servidor' });
    expect(allGroups.has('groupId')).to.be.true; 
  });
});


describe('insertUser', () => {
  it('should insert a user for valid parameters and token', async () => {
    const req = { query: { userName: 'NewUser', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'ExistingUser']]);
    const User = function(id, name) { this.id = id; this.name = name; };
    User.prototype.set = function(key, value) { this[key] = value; };
    const allUsers = new Map();

    await insertUser(req, res, users, allUsers, User);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ msg: 'Utilizador inserido com sucesso' });
    expect(allUsers.get('validToken')).to.be.an.instanceOf(User);
    expect(allUsers.get('validToken').name).to.equal('NewUser');
  });

  it('should return an error for an invalid token', async () => {
    const req = { query: { userName: 'NewUser', idToken: 'invalidToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'ExistingUser']]);
    const User = function(id, name) { this.id = id; this.name = name; };
    User.prototype.set = function(key, value) { this[key] = value; };
    const allUsers = new Map();

    await insertUser(req, res, users, allUsers, User);

    expect(res.statusCode).to.equal(403);
    expect(res.data).to.deep.equal({ erro: 'Token não válido' });
    expect(allUsers.size).to.equal(0);
  });

  it('should return an error for missing parameters', async () => {
    const req = { query: { idToken: 'validToken' } }; 
    const res = new MockResponse();
    const users = new Map([['validToken', 'ExistingUser']]);
    const User = function(id, name) { this.id = id; this.name = name; };
    User.prototype.set = function(key, value) { this[key] = value; };
    const allUsers = new Map();

    await insertUser(req, res, users, allUsers, User);

    expect(res.statusCode).to.equal(400);
    expect(res.data).to.deep.equal({ erro: 'Parâmetros mal passados' });
    expect(allUsers.size).to.equal(0); 
  });

  it('should return an error for a server error', async () => {
    const req = { query: { userName: 'NewUser', idToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'ExistingUser']]);
    const User = function(id, name) { this.id = id; this.name = name; };
    User.prototype.set = function(key, value) { this[key] = value; };
    const allUsers = new Map();

    await insertUser({ ...req, throwServerError: true }, res, users, allUsers, User);

    expect(res.statusCode).to.equal(500);
    expect(res.data).to.deep.equal({ erro: 'Erro no servidor' });
    expect(allUsers.size).to.equal(0); 
  });
});


describe('deleteEvent', () => {
  it('should delete the event for valid parameters and token', async () => {
    const req = { query: { eventId: 'eventId', userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allEvents = new Map([['eventId', { eventId: 'eventId', name: 'Event1', description: 'Description', userToken: 'validToken' }]]);

    await deleteEvent(req, res, users, allEvents);

    expect(res.statusCode).to.equal(200);
    expect(res.data).to.deep.equal({ msg: 'Evento eliminado com sucesso' });
    expect(allEvents.has('eventId')).to.be.false; 
  });

  it('should return an error for an invalid token', async () => {
    const req = { query: { eventId: 'eventId', userToken: 'invalidToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allEvents = new Map([['eventId', { eventId: 'eventId', name: 'Event1', description: 'Description', userToken: 'validToken' }]]);

    await deleteEvent(req, res, users, allEvents);

    expect(res.statusCode).to.equal(403);
    expect(res.data).to.deep.equal({ erro: 'Token inválido' });
    expect(allEvents.has('eventId')).to.be.true; 
  });

  it('should return an error for missing parameters', async () => {
    const req = { query: { userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allEvents = new Map([['eventId', { eventId: 'eventId', name: 'Event1', description: 'Description', userToken: 'validToken' }]]);

    await deleteEvent(req, res, users, allEvents);

    expect(res.statusCode).to.equal(400);
    expect(res.data).to.deep.equal({ erro: 'Parâmetro mal passado' });
    expect(allEvents.has('eventId')).to.be.true; 
  });

  it('should return an error for a non-existing event', async () => {
    const req = { query: { eventId: 'nonExistingEventId', userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allEvents = new Map();

    await deleteEvent(req, res, users, allEvents);

    expect(res.statusCode).to.equal(404);
    expect(res.data).to.deep.equal({ erro: 'Evento não encontrado' });
  });

  it('should return an error for a server error', async () => {
    const req = { query: { eventId: 'eventId', userToken: 'validToken' } };
    const res = new MockResponse();
    const users = new Map([['validToken', 'UserName']]);
    const allEvents = new Map([['eventId', { eventId: 'eventId', name: 'Event1', description: 'Description', userToken: 'validToken' }]]);

    await deleteEvent({ ...req, throwServerError: true }, res, users, allEvents);

    expect(res.statusCode).to.equal(500);
    expect(res.data).to.deep.equal({ erro: 'Erro no servidor' });
    expect(allEvents.has('eventId')).to.be.true; 
  });
});
