import fetch from 'node-fetch';
import { grupo } from './seca-data-mem.mjs';
import secaDataElastic from './data/elastic/seca-data-elastic.mjs';
//import { searchEventById } from './tm-events-data.mjs';

import secaWebSite from './seca-web-site.mjs';

const groups = 'groups';
const users = 'users';

export default function(){
    return{
        Register,
        logIn,
    }
}

async function logIn(username, password){
    const user = await secaDataElastic(users).isValidUser(username, password);
    return user;
}

async function Register(username, password){
    const user = await secaDataElastic(users).verifyNewUser(username, password);
    if(user.idToken == null){
        //ver se inseriu user console.log('inseriu')
        return await secaDataElastic(users).insertUser(user);
    } else {
        return null;
    }
}

