import crypto from 'crypto'

class grupo {
    constructor(nome, descricao, idToken) {
        this.idGrupo = crypto.randomUUID();
        this.eventos = [];
        this.descricao = descricao;
        this.idToken = idToken;
        this.nome = nome;
    }
    
    addEvent(event) {
        this.eventos.push(event);
    }
    
    removeEvent(eventId) {
        return this.eventos.filter(event => event.id !== eventId);
    }
}

class user{
    constructor(idToken, userName){
        this.idToken = idToken,
        this.userName = userName
    }
}

/*
Create a new resource that returns the event (this is not a search by id),
 which must include at least the following details: name, an image, sales start and end time, 
 event date(s), segment, genre and subGenre.
 This resource URI must contain the event ID.
*/

class event {
    constructor(name, image, salesStartTime, salesEndTime, eventDates, segment, genre, subGenre) {
        this.id = crypto.randomUUID();
        this.name = name;
        this.image = image;
        this.sales = {
            start_time: salesStartTime,
            end_time: salesEndTime
        };
        this.eventDates = eventDates;
        this.segment = segment;
        this.genre = genre;
        this.subGenre = subGenre;
    }
}

export {grupo, user, event};
