import express from 'express'
import * as secaServices from './seca-services.mjs'
//import { getPopularEvents, searchEventsByName } from './tm-events-data.mjs';


const app = express();

export function blabla(app){
    app.use('/api', app)
}

/*

app.post('/insertUser', secaServices.insertUser); //

//lista todos os groups
app.get('/grupos/allGroups', secaServices.getAllGroups);//

//rotas.get('/grupos/getPopularEvents', getPopularEvents);    //

app.get('/grupos/searchEventByName', searchEventsByName);     //

//envia dados para o servidor, sobre allGroups
app.post('/grupos/insertGroup', secaServices.insertGroup); //

//lista apenas um grupo
app.get('/grupos/getGroup', secaServices.getGroup);   //

//remover grupo
app.delete('/grupos/deleteGroup', secaServices.deleteGroup);  //

app.delete('/grupos/deleteEvent', secaServices.deleteEvent);

app.post('/grupos/addEvent', secaServices.addEvent);      

//update do grupo
app.put('/grupos/updateGroup', secaServices.updateGroup);

app.post('api/insertUser', secaServices.insertUser); 

//lista todos os groups
app.get('api/grupos', secaServices.getAllGroups);

//envia dados para o servidor, sobre allGroups
app.post('api/grupos', secaServices.getAllGroups);

//lista apenas um grupo
app.get('api/grupos/:idGrupo', secaServices.getGroup);

//remover grupo
app.delete('api/grupos/:idGrupo', secaServices.deleteGroup);

//inserir grupo
app.put('api/grupos/:idGrupo', secaServices.insertGroup);

//update do grupo
app.post('api/grupos/:idGrupo', secaServices.updateGroup);




app.post('/api/insertUser', secaServices.insertUser);

app.get('/api/grupos', secaServices.getAllGroups);

app.post('/api/grupos', secaServices.insertGroup);

app.get('/api/grupos/:idGrupo', secaServices.getGroup);

app.delete('/api/grupos/:idGrupo', secaServices.deleteGroup);

app.put('/api/grupos/:idGrupo', secaServices.updateGroup);


*/

console.log('Configuração terminada com sucesso');
