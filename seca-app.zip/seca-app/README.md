# seca-ipw-p1-leic2324i-ipw33d-g27
seca-ipw-p1-leic2324i-ipw33d-g27 created by GitHub Classroom

O nosso trabalho tem os seguintes arquivos:
- node_modules (pasta)
- testes (pasta):
    - seca-services-testes.mjs
    - seca-wbe-api-testes.mjs
    - seca-events-data-testes.mjs
- package-lock.json
- package.json
- seca-api-spec.yaml
- seca-data-mem.mjs
- seca-server.mjs
- seca-services.mjs
- seca-web-api.mjs
- tm-events-data.mjs
- web-api.md