//curl -X PUT http://localhost:9200/tasks

// Create a task
//curl -X POST --data '{ "title" : "Task1" , "description" : "task 1 elastic", "userId": "iduser" }' -H "Content-Type: application/json" http://localhost:9200/tasks/_doc


import { user } from '../../seca-data-mem.mjs';
import {get, post, del, put} from './fetch-wrapper.mjs'
import uriManager from './uri-manager.mjs'

const groups = 'groups';
const users = 'users';

export default function (indexName) {
    const URI_MANAGER =  uriManager(indexName)

    return {
        getGroups,
        getGroup,
        updateGroup,
        insertGroup,
        deleteGroup,
        insertUser,
        isValidUser,
        verifyNewUser
    }

//    async function getTasks(userId, q, skip, limit) {
    async function getGroups(userId) {
        const query = {
            query: {
              match: {
                "idToken": userId
              }
            }
          }
        return post(URI_MANAGER.getAll(), query)
            .then(body => body.hits.hits.map(createGroupFromElastic))
            //.then(filterTasks)

        // function filterTasks(tasks) {
        //     const predicate = q ? t => t.title.includes(q) : t => true
        //     const retTasks = tasks.filter(predicate)
            
        //     const end = limit != MAX_LIMIT ? (skip+limit) : retTasks.length
        //     return retTasks.slice(skip,  end)
        // }

    }
/*
    async function getGroupsQuery(userId) {
        const uri = `${URI_MANAGER.getAll()}?q=userId:${userId}`
        return get(uri)
            .then(body => body.hits.hits.map(createGroupFromElastic))
            //.then(filterTasks)

        // function filterTasks(tasks) {
        //     const predicate = q ? t => t.title.includes(q) : t => true
        //     const retTasks = tasks.filter(predicate)
            
        //     const end = limit != MAX_LIMIT ? (skip+limit) : retTasks.length
        //     return retTasks.slice(skip,  end)
        // }

    }
*/
    async function getGroup(groupId) {
        return get(URI_MANAGER.get(groupId)).then(createGroupFromElastic)
    }

    async function insertGroup(newGroup) {
        return post(URI_MANAGER.create(), newGroup)
            .then(body => { newGroup.id = body._id; return newGroup; });
    }

    async function updateGroup(groupToUpdate) {
        return put(URI_MANAGER.update(groupToUpdate.id), groupToUpdate)
    }

    async function deleteGroup(groupId) {
        return del(URI_MANAGER.delete(groupId))
            .then(body => body._id)
    }

    async function insertUser(newUser){
        return post(URI_MANAGER.create(), newUser)
            .then(body => {newUser.idToken = body._id; return newUser});
    }
    
    async function isValidUser(username, password) {
        console.log('is valid called')
        let user = {username: username, password: password};
        const query = {
            query: {
                bool: {
                    must: [
                        { match: { "username": username } },
                        { match: { "password": password } }
                    ]
                }
            }
        };
    
        return post(URI_MANAGER.getAll(), query).then(body => {
        if (body.hits.hits.length > 0) {
            user.idToken = body.hits.hits[0]._id
            return user;
        } else {
            user.idToken = null
            return user;
        }
        });
    }
    
    async function verifyNewUser(username, password){
        console.log('verify called')
        let user = {username: username, password: password};
        const query = {
            query: {
                bool: {
                    must: [
                        { match: { "username": username } }
                    ]
                }
            }
        };
    
        return post(URI_MANAGER.getAll(users), query).then(body => {
            
        if (body.hits.hits.length == 0) {
            //caso ele n encontre nenhum user igual
            console.log(user)
            user.idToken = null
            return user;
        } else {
            //caso ele encontre um user com o mesmo nisckname
            user.idToken = body.hits.hits[0]._id;
            console.log(user,' else')
            return user;
        }
        });
    
        
    }

    function createGroupFromElastic(groupElastic) {
        let grupo = Object.assign({id: groupElastic._id}, groupElastic._source)
        return grupo
    }
}

// async function post(url, data) {
//     const requestOptions = {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(data),
//     };

//     return fetch(url, requestOptions)
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error(`HTTP error! Status: ${response.status}`);
//             }
//             return response.json();
//         })
//         .catch(error => {
//             console.error('Error making POST request:', error);
//             throw error;
//         });
// }