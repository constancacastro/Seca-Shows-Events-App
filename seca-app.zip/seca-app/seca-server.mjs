import express from 'express'
import { blabla } from './seca-web-api.mjs';
import {engine} from 'express-handlebars';
import { secaWebSite } from './seca-web-site.mjs';
import secaServices from './seca-services.mjs';
import { getPopularEvents, searchEventsByName, searchEventById, searchEventsByNameNoId } from './tm-events-data.mjs';
import {grupo, user, event} from './seca-data-mem.mjs';
{grupo, user, event}

import passport from 'passport';
import expressSession from 'express-session';


const PORT = 3000 ;
import bodyParser from 'body-parser'; //processar os dados do corpo da requisição
import secaDataElastic from './data/elastic/seca-data-elastic.mjs';


const app = express();  //iniciar um objeto express
// blabla(app)
app.engine('handlebars', engine('main'));
app.set('view engine', 'handlebars');
app.use(express.urlencoded());

app.use(express.static('public')); //fazer com que aceda à pasta onde está o css

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(expressSession({secret: 'g27', resave: false, saveUninitialized: false}));

app.use(passport.session());
app.use(passport.initialize());

passport.serializeUser(serializeUserDeserializeUser);
passport.deserializeUser(serializeUserDeserializeUser)

function serializeUserDeserializeUser(user, done){
   done(null, user);
}

//rotas site
app.get('/home', (req,res) => {
   res.render('home', { title: 'SECA',
   style: 'public/style/allCss.css'
   })
});

//rota login
app.get('/home/login', (req, res) => {
   res.render('login', { title: 'SECA' ,
   style: 'public/style/allCss.css'
   });
});

//rota registo
app.get('/home/register', (req, res) => {
   res.render('register', { title: 'SECA' ,
   style: 'public/style/allCss.css'
   });
});



app.post('/home/userpage', (req, res) => {
   res.render('userpage', { title: 'SECA' , 
   style: 'public/style/allCss.css'
   });
});

app.get('/home/groups', (req, res) => {
   res.render('groups', { title: 'SECA' ,
   style: 'public/style/allCss.css'
  });
});

app.post('home/groups',(req, res) => {
   res.render('groups', { title: 'SECA' ,
   style: 'public/style/allCss.css'
  });
});

app.get('/home/searchevents', (req, res) => {
   res.render('searcheventsnogroup',
   {  title: 'Search for Events' ,
      style: 'public/style/allCss.css'
   });
});

//rotas pra paginas
app.get('/home/loginpage', (req, res) => {
   res.render('login', 
   {
      action: '/home/login',
      style: 'public/style/allCss.css',
      buttonValue: 'Login'
   });
});

app.get('/home/signuppage', (req, res) => {
   res.render('register', 
   {action: '/home/signup',
   style: 'public/style/allCss.css',
    buttonValue: 'Sign up'});
});


app.get('/home/search', (req, res) => {
   res.render('searcheventsnogroup', {
      title: 'Search for Events',
      style: 'public/style/allCss.css'
   });
});


app.get('/home/userpage', (req, res) => {
   res.render('userpage', { title: 'SECA' , 
   style: 'public/style/allCss.css'
   });
});
// //rotas para elastic
app.post('/home/login', secaWebSite.login); //

app.post('/home/signup', secaWebSite.register); //

//app.get('/home/groups/:idToken', secaWebSite.getGroups); // P3
app.get('/home/groups/valid', secaWebSite.getGroups);

//app.post('/home/groups/:idToken', secaWebSite.getGroups);

//app.post('/home/:idToken/groups/create', secaWebSite.createGroup); // P3
app.post('/home/valid/groups/create', secaWebSite.createGroup);

//app.get('/home/groups/:idGrupo/details', secaWebSite.getDetails); // P3
app.post('/home/groups/valid/details', secaWebSite.getDetails); //


//app.get('/home/groups/:idGrupo/editpage', secaWebSite.renderEditPage); // P3
app.post('/home/groups/valid/editpage', secaWebSite.renderEditPage); //

//app.post('/home/groups/:idGrupo/edit', secaWebSite.updateGroup); // P3
app.post('/home/groups/valid/edit', secaWebSite.updateGroup); 

//app.post('/home/groups/:idGrupo/delete', secaWebSite.deleteGroup);// P3
app.post('/home/groups/valid/delete', secaWebSite.deleteGroup);

//app.post('/home/groups/:GroupId/:eventId/deleteEvent', secaWebSite.deleteEvent); // P3
app.post('/home/groups/valid/deleteEvent', secaWebSite.deleteEvent); 

//app.get('/addEvent/:idGrupo', secaWebSite.loadAddEvent); //P3
app.post('/loadSearchEventPage/valid', secaWebSite.loadAddEvent);

app.get('/home/searcheventsnogroup', searchEventsByNameNoId); //

//app.get('/searchEventByName/:idGrupo', searchEventsByName);  // P3
app.post('/searchEventByName/valid', searchEventsByName);

app.post('/addEvent/group/event/valid', secaWebSite.addEventToGroup)




/*
app.post('/home/login', secaWebSite.login); //
app.post('/home/signup', secaWebSite.register); //
app.get('/home/groups/:idToken', secaWebSite.getGroups);
app.post('/home/:idToken/groups/create', secaWebSite.createGroup);
app.get('/home/groups/:idGrupo/details', secaWebSite.getDetails);
app.post('/rotadoupdate/:idGrupo', secaWebSite.updateGroup);
app.post('/rotadodelete/:idGrupo', secaWebSite.deleteGroup);
app.get('/rotadoadd/:idGrupo', secaWebSite.loadAddEvent);
app.get('/rotadosevents/:idGrupo', searchEventsByName); //nao esquecer de meter idGrupo
app.post('/addgroup/:idGrupo', secaWebSite.addEventToGroup)
*/

app.listen(PORT, () => {
   console.log(`Servidor está a correr na porta ${PORT}`); 
}); //inicializar o servidor

//mudei so os ficheiros que tao fora das pastas, dentro do views
